import React, { ReactNode } from 'react';

export interface NavItem {
  label: string;
  path: string;
}

export interface FeatureCardProps {
  title: string;
  description: string;
  icon: ReactNode;
}

export interface SectionProps {
  id?: string;
  className?: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface SensorDataPoint {
  time: string;
  moisture: number;
  temperature: number;
}