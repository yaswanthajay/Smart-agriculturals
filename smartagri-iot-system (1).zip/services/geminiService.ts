import { GoogleGenAI, Chat } from "@google/genai";
import { PROJECT_CONTEXT } from '../constants';

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// Initialize chat with system instruction
let chatSession: Chat | null = null;

export const getChatSession = (): Chat => {
  if (!chatSession) {
    chatSession = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: PROJECT_CONTEXT,
      },
    });
  }
  return chatSession;
};

export const sendMessageToAssistant = async (message: string) => {
  const chat = getChatSession();
  // Using stream for better UX
  const result = await chat.sendMessageStream({ message });
  return result;
};
