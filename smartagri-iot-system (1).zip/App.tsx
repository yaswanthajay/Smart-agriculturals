import React from 'react';
import { Routes, Route, HashRouter } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import About from './pages/About';
import Features from './pages/Features';
import Working from './pages/Working';
import Literature from './pages/Literature';
import Results from './pages/Results';
import Conclusion from './pages/Conclusion';
import Contact from './pages/Contact';
import AIChat from './components/AIChat';

const App: React.FC = () => {
  return (
    <HashRouter>
      <div className="flex flex-col min-h-screen bg-white">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/features" element={<Features />} />
            <Route path="/working" element={<Working />} />
            <Route path="/literature" element={<Literature />} />
            <Route path="/results" element={<Results />} />
            <Route path="/conclusion" element={<Conclusion />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>
        <AIChat />
        <Footer />
      </div>
    </HashRouter>
  );
};

export default App;
