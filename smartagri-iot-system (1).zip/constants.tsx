import { NavItem, SensorDataPoint } from './types';
import { Leaf, Droplets, Cpu, Wifi, Activity, Smartphone } from 'lucide-react';
import React from 'react';

export const NAV_ITEMS: NavItem[] = [
  { label: 'Home', path: '/' },
  { label: 'About', path: '/about' },
  { label: 'Features', path: '/features' },
  { label: 'Working', path: '/working' },
  { label: 'Literature', path: '/literature' },
  { label: 'Results', path: '/results' },
  { label: 'Conclusion', path: '/conclusion' },
  { label: 'Contact', path: '/contact' },
];

export const FEATURES_DATA = [
  {
    title: 'IoT Monitoring',
    description: 'Continuous environmental monitoring using networked sensors to track micro-climate conditions.',
    icon: <Wifi className="w-8 h-8 text-emerald-600" />
  },
  {
    title: 'Soil Moisture Detection',
    description: 'Precision reading using the F-28 Soil Moisture sensor to determine exact water requirements.',
    icon: <Droplets className="w-8 h-8 text-blue-500" />
  },
  {
    title: 'Automated Irrigation',
    description: 'Smart pump control system that activates sprinklers only when soil moisture drops below threshold.',
    icon: <Cpu className="w-8 h-8 text-orange-500" />
  },
  {
    title: 'Cloud Integration',
    description: 'Real-time data transmission to cloud platforms via MQTT for storage and analysis.',
    icon: <Activity className="w-8 h-8 text-purple-500" />
  },
  {
    title: 'Mobile Dashboard',
    description: 'User-friendly mobile and web interface to view live sensor data and control manual overrides.',
    icon: <Smartphone className="w-8 h-8 text-gray-700" />
  },
  {
    title: 'Eco-Friendly',
    description: 'Optimizes resource usage, reducing water waste by up to 40% compared to traditional methods.',
    icon: <Leaf className="w-8 h-8 text-green-500" />
  }
];

export const MOCK_SENSOR_DATA: SensorDataPoint[] = [
  { time: '08:00', moisture: 45, temperature: 22 },
  { time: '10:00', moisture: 42, temperature: 24 },
  { time: '12:00', moisture: 35, temperature: 28 },
  { time: '14:00', moisture: 20, temperature: 30 }, // Pump triggers here usually
  { time: '16:00', moisture: 80, temperature: 29 }, // Post-irrigation
  { time: '18:00', moisture: 75, temperature: 26 },
  { time: '20:00', moisture: 70, temperature: 24 },
];

export const PROJECT_CONTEXT = `
You are the AI assistant for the "Smart Agriculture System using IoT and Automation" project.
Project Details:
- Objective: Automate irrigation and monitor soil health.
- Key Sensors: F-28 Soil Moisture Sensor, DHT11 Temperature/Humidity.
- Controller: NodeMCU (ESP8266) or Arduino Uno.
- Communication: WiFi, MQTT protocol.
- Actuators: 5V Relay Module, Water Pump.
- Results: Reduced water wastage, real-time analytics.
Answer questions briefly and accurately based on this context.
`;
