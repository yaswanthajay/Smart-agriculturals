import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { MOCK_SENSOR_DATA } from '../constants';

const Results: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 bg-gray-50 min-h-screen">
      <h1 className="text-4xl font-bold text-gray-900 mb-8 text-center">Results & Data Analysis</h1>

      <div className="grid lg:grid-cols-2 gap-8 mb-12">
        {/* Soil Moisture Chart */}
        <div className="bg-white p-6 rounded-xl shadow-md">
          <h3 className="text-xl font-semibold mb-4 text-emerald-800">Soil Moisture (%) - Daily Trend</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={MOCK_SENSOR_DATA}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis unit="%" />
                <Tooltip />
                <Area type="monotone" dataKey="moisture" stroke="#059669" fill="#d1fae5" strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <p className="text-sm text-gray-500 mt-4 text-center">
            Graph shows moisture drop during the day and rapid rise at 14:00 due to automated irrigation trigger.
          </p>
        </div>

        {/* Temperature Chart */}
        <div className="bg-white p-6 rounded-xl shadow-md">
          <h3 className="text-xl font-semibold mb-4 text-orange-800">Ambient Temperature (°C)</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={MOCK_SENSOR_DATA}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis unit="°C" />
                <Tooltip />
                <Line type="monotone" dataKey="temperature" stroke="#ea580c" strokeWidth={3} dot={{ r: 5 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="text-sm text-gray-500 mt-4 text-center">
            Temperature peaks at midday, correlating with increased evaporation rates.
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-800">Visual Evidence</h3>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <img src="https://picsum.photos/id/10/400/300" alt="Field Before" className="rounded-lg shadow w-full" />
                    <p className="text-center text-sm font-medium mt-2">Before Irrigation</p>
                </div>
                 <div>
                    <img src="https://picsum.photos/id/11/400/300" alt="Field After" className="rounded-lg shadow w-full" />
                    <p className="text-center text-sm font-medium mt-2">After Smart Irrigation</p>
                </div>
            </div>
        </div>

        <div className="bg-white p-8 rounded-xl border-l-4 border-emerald-500 shadow-sm">
            <h3 className="text-2xl font-bold text-gray-800 mb-4">Key Findings</h3>
            <ul className="space-y-3 text-gray-700">
                <li className="flex items-start gap-2">
                    <span className="text-emerald-500 font-bold">•</span>
                    System successfully maintained soil moisture between 60-80% threshold.
                </li>
                <li className="flex items-start gap-2">
                    <span className="text-emerald-500 font-bold">•</span>
                    Water usage reduced by approximately 35% compared to timed watering.
                </li>
                <li className="flex items-start gap-2">
                    <span className="text-emerald-500 font-bold">•</span>
                    Real-time alerts were received with latency under 2 seconds.
                </li>
                <li className="flex items-start gap-2">
                    <span className="text-emerald-500 font-bold">•</span>
                    Sensor accuracy variance was found to be within ±2%.
                </li>
            </ul>
        </div>
      </div>
    </div>
  );
};

export default Results;
