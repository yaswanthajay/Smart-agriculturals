import React from 'react';

const Literature: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900">Literature Review</h1>
        <p className="mt-4 text-gray-600 italic">Exploring existing research and advancements in Smart Agriculture.</p>
      </div>

      <div className="space-y-12">
        <article className="prose prose-emerald max-w-none">
          <h3 className="text-2xl font-semibold text-emerald-800 border-b pb-2 mb-4">IoT in Agriculture</h3>
          <p className="text-gray-700 leading-relaxed mb-6">
            The integration of Internet of Things (IoT) in agriculture has shifted the paradigm from traditional heuristics-based farming to data-driven precision agriculture. Research by <em>Smith et al. (2020)</em> demonstrates that IoT sensor networks can increase crop productivity by 15-20% while reducing resource inputs. The ability to monitor field conditions remotely enables "Smart Farming," reducing the need for physical presence and allowing for scalability across large hectares of land.
          </p>

          <h3 className="text-2xl font-semibold text-emerald-800 border-b pb-2 mb-4">Smart Irrigation Systems</h3>
          <p className="text-gray-700 leading-relaxed mb-6">
            Automated irrigation is a critical component of modern agriculture. Studies have shown that soil moisture-based irrigation scheduling is significantly more efficient than time-based scheduling. <em>Gondchawar and Kawitkar (2016)</em> proposed a system using varied sensors and found that automated systems could save up to 40% of water usage. The implementation of soil moisture sensors like the resistive or capacitive types (F-28) provides the feedback loop necessary for closed-loop control systems.
          </p>

          <h3 className="text-2xl font-semibold text-emerald-800 border-b pb-2 mb-4">Machine Learning in Smart Farming</h3>
          <p className="text-gray-700 leading-relaxed mb-6">
            Recent advancements utilize Machine Learning (ML) to predict environmental changes and crop diseases. By analyzing historical sensor data, ML models can forecast drought conditions or irrigation needs days in advance. While our current project focuses on automation based on real-time thresholds, the literature suggests that integrating predictive analytics is the next logical step for maximizing efficiency and yield quality.
          </p>

          <h3 className="text-2xl font-semibold text-emerald-800 border-b pb-2 mb-4">Related Work</h3>
          <p className="text-gray-700 leading-relaxed">
            Several commercial solutions exist, such as CropX and Arable, but they are often cost-prohibitive for small-scale farmers. DIY solutions using Arduino and Raspberry Pi, as explored in open-source communities, provide a cost-effective alternative. This project builds upon these foundations by creating a robust, low-cost architecture that combines reliable sensing with user-friendly visualization.
          </p>
        </article>
      </div>
    </div>
  );
};

export default Literature;
