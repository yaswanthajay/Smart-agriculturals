import React from 'react';

const Working: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <h1 className="text-4xl font-bold text-gray-900 mb-12 text-center">System Implementation & Workflow</h1>

      <div className="space-y-20">
        {/* Step 1 */}
        <div className="flex flex-col md:flex-row gap-10 items-center">
          <div className="md:w-1/2">
             <img src="https://picsum.photos/id/250/600/400" alt="Sensor Deployment" className="rounded-xl shadow-lg w-full" />
          </div>
          <div className="md:w-1/2">
            <div className="flex items-center gap-4 mb-4">
              <span className="bg-emerald-600 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold text-xl">1</span>
              <h2 className="text-2xl font-bold text-gray-800">Sensor Deployment</h2>
            </div>
            <p className="text-gray-600 leading-relaxed mb-4">
              The F-28 Soil Moisture sensor is embedded into the soil near the root zone of the plants. It measures the volumetric water content by utilizing the dielectric constant of the soil. Additionally, DHT11/DHT22 sensors are placed to monitor ambient temperature and humidity.
            </p>
          </div>
        </div>

        {/* Step 2 */}
        <div className="flex flex-col md:flex-row-reverse gap-10 items-center">
          <div className="md:w-1/2">
             <img src="https://picsum.photos/id/60/600/400" alt="Microcontroller" className="rounded-xl shadow-lg w-full" />
          </div>
          <div className="md:w-1/2">
             <div className="flex items-center gap-4 mb-4">
              <span className="bg-emerald-600 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold text-xl">2</span>
              <h2 className="text-2xl font-bold text-gray-800">Data Acquisition</h2>
            </div>
            <p className="text-gray-600 leading-relaxed mb-4">
              The analog signals from the sensors are read by the NodeMCU (ESP8266) or Arduino microcontroller. The system converts these analog readings into digital percentage values (0-100%) to determine the moisture level.
            </p>
          </div>
        </div>

        {/* Step 3 */}
        <div className="flex flex-col md:flex-row gap-10 items-center">
          <div className="md:w-1/2">
             <img src="https://picsum.photos/id/534/600/400" alt="Automation" className="rounded-xl shadow-lg w-full" />
          </div>
          <div className="md:w-1/2">
             <div className="flex items-center gap-4 mb-4">
              <span className="bg-emerald-600 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold text-xl">3</span>
              <h2 className="text-2xl font-bold text-gray-800">Logic & Automation</h2>
            </div>
            <p className="text-gray-600 leading-relaxed mb-4">
              The code running on the microcontroller checks if the moisture level falls below a critical threshold (e.g., 30%). If true, it triggers a 5V relay module which activates the water pump or solenoid valve for the sprinklers. Once the threshold is reached, the pump turns off automatically.
            </p>
          </div>
        </div>

        {/* Step 4 */}
        <div className="flex flex-col md:flex-row-reverse gap-10 items-center">
          <div className="md:w-1/2">
             <img src="https://picsum.photos/id/3/600/400" alt="Cloud Dashboard" className="rounded-xl shadow-lg w-full" />
          </div>
          <div className="md:w-1/2">
             <div className="flex items-center gap-4 mb-4">
              <span className="bg-emerald-600 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold text-xl">4</span>
              <h2 className="text-2xl font-bold text-gray-800">Cloud & Visualization</h2>
            </div>
            <p className="text-gray-600 leading-relaxed mb-4">
              Data is transmitted via Wi-Fi using the MQTT protocol to a cloud dashboard (e.g., Blynk, ThingSpeak, or a custom Web App). This allows the user to visualize historical data graphs, current status, and receive alerts on their mobile device.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Working;
