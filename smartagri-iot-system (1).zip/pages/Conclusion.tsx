import React from 'react';
import { Rocket, CheckCircle } from 'lucide-react';

const Conclusion: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      
      {/* Conclusion Section */}
      <section className="mb-20 text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-8">Conclusion</h1>
        <div className="bg-emerald-50 rounded-2xl p-8 md:p-12 max-w-4xl mx-auto shadow-sm">
          <div className="flex justify-center mb-6">
            <CheckCircle className="w-16 h-16 text-emerald-600" />
          </div>
          <p className="text-lg text-gray-700 leading-relaxed mb-6">
            The Smart Agriculture System using IoT and Automation has successfully demonstrated that low-cost technology can revolutionize farming practices. By automating irrigation based on real-time soil moisture data, the system eliminates guesswork, conserves significant amounts of water, and ensures optimal growing conditions for crops.
          </p>
          <p className="text-lg text-gray-700 leading-relaxed">
            The integration of cloud computing allows for remote monitoring, making it a convenient solution for modern farmers. This project serves as a stepping stone towards more sustainable and efficient agricultural practices.
          </p>
        </div>
      </section>

      {/* Future Work Section */}
      <section>
        <div className="flex items-center justify-center gap-4 mb-10">
            <Rocket className="w-10 h-10 text-blue-600" />
            <h2 className="text-3xl font-bold text-gray-900">Future Enhancements</h2>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
            <div className="border border-gray-200 p-6 rounded-xl hover:bg-gray-50 transition-colors">
                <h3 className="text-xl font-bold text-gray-800 mb-3">AI & Predictive Analytics</h3>
                <p className="text-gray-600">
                    Implementing machine learning algorithms to predict irrigation needs based on weather forecasts (rain probability) to further save water.
                </p>
            </div>
             <div className="border border-gray-200 p-6 rounded-xl hover:bg-gray-50 transition-colors">
                <h3 className="text-xl font-bold text-gray-800 mb-3">Drone Integration</h3>
                <p className="text-gray-600">
                    Using agricultural drones for aerial surveillance, crop health imaging (NDVI), and targeted pesticide spraying.
                </p>
            </div>
             <div className="border border-gray-200 p-6 rounded-xl hover:bg-gray-50 transition-colors">
                <h3 className="text-xl font-bold text-gray-800 mb-3">Blockchain for Supply Chain</h3>
                <p className="text-gray-600">
                    Integrating blockchain to track the crop lifecycle from farm to fork, ensuring transparency and quality assurance for consumers.
                </p>
            </div>
        </div>
      </section>

    </div>
  );
};

export default Conclusion;
