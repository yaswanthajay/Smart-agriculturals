import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Activity, CloudSun, Sprout } from 'lucide-react';
import { motion } from 'framer-motion';

const Home: React.FC = () => {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center text-center text-white overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://picsum.photos/id/429/1920/1080" 
            alt="Smart Farming" 
            className="w-full h-full object-cover filter brightness-50"
          />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-4">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-4xl md:text-6xl font-bold mb-6"
          >
            Smart Agriculture System
            <br />
            <span className="text-emerald-400 text-2xl md:text-4xl block mt-2 font-medium">IoT, Sensors & Automation</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="text-xl md:text-2xl mb-8 font-light"
          >
            “Revolutionizing Farming Through Technology”
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link to="/about" className="px-8 py-3 bg-emerald-600 hover:bg-emerald-700 rounded-full font-semibold transition-transform transform hover:scale-105 flex items-center justify-center gap-2">
              Learn More <ArrowRight size={20} />
            </Link>
            <Link to="/features" className="px-8 py-3 bg-white text-emerald-900 hover:bg-gray-100 rounded-full font-semibold transition-transform transform hover:scale-105">
              Project Details
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Quick Intro */}
      <section className="py-20 bg-emerald-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Smart Agriculture?</h2>
            <p className="max-w-2xl mx-auto text-gray-600">
              Integrating IoT and automation optimizes crop yields, conserves water, and reduces manual labor, creating a sustainable future for farming.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4 text-emerald-600">
                <Activity />
              </div>
              <h3 className="text-xl font-semibold mb-2">Real-time Data</h3>
              <p className="text-gray-600">Instant feedback on soil conditions ensuring crops get exactly what they need.</p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow">
               <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4 text-blue-600">
                <CloudSun />
              </div>
              <h3 className="text-xl font-semibold mb-2">Weather Adaptive</h3>
              <p className="text-gray-600">Automated systems that adjust irrigation based on environmental patterns.</p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow">
               <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4 text-orange-600">
                <Sprout />
              </div>
              <h3 className="text-xl font-semibold mb-2">Better Yields</h3>
              <p className="text-gray-600">Healthier plants through precision farming techniques and reduced disease risks.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;