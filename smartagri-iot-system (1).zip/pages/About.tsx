import React from 'react';

const About: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">About The Project</h1>
        <div className="h-1 w-20 bg-emerald-500 rounded"></div>
      </div>

      <div className="grid md:grid-cols-2 gap-12 items-start">
        <div className="space-y-8">
          <section>
            <h2 className="text-2xl font-semibold text-emerald-800 mb-4">Problem Statement</h2>
            <p className="text-gray-700 leading-relaxed">
              Traditional agriculture suffers from inefficient water management, often leading to either over-irrigation or under-irrigation. Manual monitoring of large fields is labor-intensive and prone to human error. Furthermore, lack of real-time data on soil moisture levels (using precision sensors like F-28) results in resource wastage and suboptimal crop health.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-emerald-800 mb-4">Project Objectives</h2>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>To develop an automated irrigation system based on real-time soil moisture data.</li>
              <li>To implement IoT-based monitoring for remote data access.</li>
              <li>To reduce water consumption and improve sustainability in farming practices.</li>
              <li>To visualize environmental data through a user-friendly dashboard.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-emerald-800 mb-4">Scope & Limitations</h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              <strong>Scope:</strong> This system is designed for greenhouses, small-to-medium farms, and home gardens. It covers soil moisture sensing, temperature monitoring, and automated pump control.
            </p>
            <p className="text-gray-700 leading-relaxed">
              <strong>Limitations:</strong> Requires a stable power source and Wi-Fi connectivity. The current prototype uses limited sensors, which can be scaled up for larger industrial applications.
            </p>
          </section>
        </div>

        <div className="space-y-8">
          <div className="rounded-2xl overflow-hidden shadow-lg">
            <img src="https://picsum.photos/id/292/800/600" alt="Farmer with tablet" className="w-full h-auto object-cover" />
          </div>
          
          <section className="bg-emerald-50 p-6 rounded-xl border border-emerald-100">
            <h2 className="text-2xl font-semibold text-emerald-800 mb-4">Sustainability Impact</h2>
            <p className="text-gray-700 leading-relaxed">
              Smart farming is crucial for the future. By automating water delivery, we not only conserve a precious resource but also prevent soil erosion and nutrient leaching. This project demonstrates how low-cost technology can have a high impact on ecological preservation.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default About;
